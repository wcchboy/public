package com.olivephone.sdk.demo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import junit.framework.Assert;

import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.Locale;
import java.util.Stack;

public class FileChooserActivity extends Activity {
	public static final String EXTRA_FILE_NAME = "FILE";
	private static String[] PERMISSIONS_STORAGE = {
			Manifest.permission.READ_EXTERNAL_STORAGE,
			Manifest.permission.WRITE_EXTERNAL_STORAGE};
	//请求状态码
	private static int REQUEST_PERMISSION_CODE = 1;

	static final FileFilter FILE_FILTER = new FileFilter() {
		@Override
		public boolean accept(File file) {
			String fileName = file.getName().toLowerCase(Locale.US);
			if (fileName.startsWith(".")) {
				return false;
			}

			return file.isDirectory() || fileName.endsWith(".txt") || fileName.endsWith(".doc") || fileName.endsWith(".docx") || fileName.endsWith(".ppt") || fileName.endsWith(".xlsx") || fileName.endsWith(".xls") || fileName.endsWith(".pptx");
		}
	};

	private static class DirEntry {
		public FileEntry dir;
		public int firstVisibleItem;
		public int firstVisibleItemOffset;

		public DirEntry(File dir) {
			this.dir = new FileEntry(dir);
		}

		public DirEntry(FileEntry dir) {
			this.dir = dir;
		}
	}

	private static class FileEntry implements Comparable<FileEntry> {
		public File file;

		FileEntry(File file) {
			this.file = file;
		}

		public FileEntry[] listFiles(FileFilter fileFilter) {
			File[] files = this.file.listFiles(fileFilter);
			if (files != null) {
				FileEntry[] result = new FileEntry[files.length];
				for (int i = 0; i < result.length; i++) {
					result[i] = new FileEntry(files[i]);
				}
				return result;
			}
			return null;
		}

		@Override
		public String toString() {
			if (this.file.isDirectory()) {
				return "[目录]" + this.file.getName();
			} else {
				return this.file.getName();
			}
		}

		public boolean isFile() {
			return this.file.isFile();
		}

		public String getPath() {
			return this.file.getPath();
		}

		@Override
		public int compareTo(FileEntry another) {
			return this.file.getName().toLowerCase(Locale.US).compareTo(another.file.getName().toLowerCase(Locale.US));
		}
	}

	private Stack<DirEntry> dirStack;

	private ListView fileList;

	public FileChooserActivity() {
		this.dirStack = new Stack<DirEntry>();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//检查SD卡读写权限
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
				ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE, REQUEST_PERMISSION_CODE);
			}
		}

		this.fileList = new ListView(this);
		this.setContentView(this.fileList);
		File root = Environment.getExternalStorageDirectory();
		DirEntry sdcardRootDir = new DirEntry(root);
		this.dirStack.push(sdcardRootDir);
		FileChooserActivity.this.updateAdapter();

		this.fileList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				FileEntry file = (FileEntry) parent.getAdapter().getItem(position);
				if (file.isFile()) {
					FileChooserActivity.this.open(file.getPath());
				} else {
					DirEntry parentDir = FileChooserActivity.this.dirStack.peek();
					parentDir.firstVisibleItem = parent.getFirstVisiblePosition();
					parentDir.firstVisibleItemOffset = parent.getChildAt(0).getTop();

					DirEntry entry = new DirEntry(file);
					FileChooserActivity.this.dirStack.push(entry);
					FileChooserActivity.this.updateAdapter();
				}
			}
		});
	}

	void updateAdapter() {
		DirEntry dir = this.dirStack.peek();
		int firstVisibleItem = dir.firstVisibleItem;
		int firstVisibleItemOffset = dir.firstVisibleItemOffset;

		FileEntry[] childFiles = dir.dir.listFiles(FILE_FILTER);
		Arrays.sort(childFiles);

		this.fileList.setAdapter(new ArrayAdapter<FileEntry>(this, android.R.layout.simple_list_item_1, childFiles));
		this.fileList.setSelectionFromTop(firstVisibleItem, firstVisibleItemOffset);
		this.setTitle(dir.dir.file.getPath());
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			this.dirStack.pop();
			if (this.dirStack.isEmpty()) {
				this.finish();
			} else {
				this.updateAdapter();
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * 打开文件
	 * 
	 * @param filePath
	 */
	private void open(String filePath) {
		String ext = filePath.substring(filePath.lastIndexOf('.')).toLowerCase(Locale.US);
		Class<? extends BaseDocumentActivity> targetActivity = null;
		if (ext.endsWith(".doc") || ext.endsWith(".docx") || ext.endsWith(".txt")) {
			targetActivity = WordActivity.class;
		} else if (ext.endsWith(".xls") || ext.endsWith(".xlsx")) {
			targetActivity = SpreadsheetActivity.class;
		} else if (ext.endsWith(".ppt") || ext.endsWith(".pptx")) {
			targetActivity = PresentationActivity.class;
		} else {
			Assert.fail();
		}
		Intent intent = new Intent(this, targetActivity);
		intent.putExtra(EXTRA_FILE_NAME, filePath);
		this.startActivity(intent);
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == REQUEST_PERMISSION_CODE) {
			for (int i = 0; i < permissions.length; i++) {
				Log.i("FileChooserActivity", "申请的权限为：" + permissions[i] + ",申请结果：" + grantResults[i]);
			}
		}
	}
}
