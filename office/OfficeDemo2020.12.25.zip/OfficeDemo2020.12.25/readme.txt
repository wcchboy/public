命令行编译:
gradlew clean
gradlew assembleRelease

